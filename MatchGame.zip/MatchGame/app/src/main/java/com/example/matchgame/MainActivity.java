package com.example.matchgame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.TintTypedArray;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView img1 , img2 , img3 , img4 , img5 , img6;
    Button btnNext,btnExit;


    Integer [] img  = {R.drawable.ameed , R.drawable.blk , R.drawable.starbucks , R.drawable.blend , R.drawable.gerard , R.drawable.matrix};
    int count = 0;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);
        img4 = findViewById(R.id.img4);
        img5 = findViewById(R.id.img5);
        img6 = findViewById(R.id.img6);
        btnNext = findViewById(R.id.btnNext);
        btnExit = findViewById(R.id.btnExit);
        btnNext.setEnabled(false);
        btnExit.setEnabled(false);
        btnExit.setVisibility(View.GONE);


        List <Integer> list = Arrays.asList(img);
        Collections.shuffle(list);
        list.toArray(img);

    }

    public void img1(View view) {
        img1.setImageResource(img[0]);
        if (img[0] == R.drawable.starbucks) {
            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            btnExit.setEnabled(true);
            btnExit.setVisibility(View.VISIBLE);

        }
        else
            count+=1;

        if(count == 5) {
            btnNext.setEnabled(true);
            Toast.makeText(this, "You Won!!", Toast.LENGTH_SHORT).show();
        }
    }
    public void img2(View view) {
        img2.setImageResource(img[1]);

        if (img[1] == R.drawable.starbucks){
            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            btnExit.setEnabled(true);
            btnExit.setVisibility(View.VISIBLE);

    }
        else
            count+=1;
        if(count == 5) {
            btnNext.setEnabled(true);
            Toast.makeText(this, "You Won!!", Toast.LENGTH_SHORT).show();
        }
    }
    public void img3(View view) {
        img3.setImageResource(img[2]);
        if (img[2] == R.drawable.starbucks){
            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            btnExit.setEnabled(true);
            btnExit.setVisibility(View.VISIBLE);

    }
        else
            count+=1;
        if(count == 5) {
            btnNext.setEnabled(true);
            Toast.makeText(this, "You Won!!", Toast.LENGTH_SHORT).show();
        }
    }

    public void img4(View view) {
        img4.setImageResource(img[3]);
        if (img[3] == R.drawable.starbucks){
            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            btnExit.setEnabled(true);
            btnExit.setVisibility(View.VISIBLE);

    }
        else
            count+=1;
        if(count == 5) {
            btnNext.setEnabled(true);
            Toast.makeText(this, "You Won!!", Toast.LENGTH_SHORT).show();
        }
    }
    public void img5(View view) {
        img5.setImageResource(img[4]);
        if (img[4] == R.drawable.starbucks){
            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            btnExit.setEnabled(true);
            btnExit.setVisibility(View.VISIBLE);

    }
        else
            count+=1;
        if(count == 5) {
            btnNext.setEnabled(true);
            Toast.makeText(this, "You Won!!", Toast.LENGTH_SHORT).show();
        }

    }
    public void img6(View view) {
        img6.setImageResource(img[5]);
        if (img[5] == R.drawable.starbucks) {
            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            btnExit.setEnabled(true);
            btnExit.setVisibility(View.VISIBLE);

        }
        else
            count+=1;
        if(count == 5) {
            btnNext.setEnabled(true);
            Toast.makeText(this, "You Won!!", Toast.LENGTH_SHORT).show();
        }
    }
    public void btnNextLevel(View view) {
        Intent intent = new Intent(this , Level2.class);
        startActivity(intent);

    }

    public void btnExitApp(View view) {
        Intent intent = new Intent(this , MainActivity.class);
        startActivity(intent);


    }
}