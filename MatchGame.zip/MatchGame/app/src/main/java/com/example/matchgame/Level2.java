package com.example.matchgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Level2 extends AppCompatActivity {
    ImageView im1 , im2 , im3 , im4 , im5 , im6 , im7 , im8 , im9;
    TextView txt;
    Button btnAgain;
    Integer [] imgs = {R.drawable.ameed , R.drawable.blk , R.drawable.starbucks , R.drawable.blend ,
            R.drawable.gerard , R.drawable.matrix , R.drawable.wazzupdog ,
            R.drawable.shawermasajj , R.drawable.maarouf };

    int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level2);
        im1 = findViewById(R.id.im1);
        im2 = findViewById(R.id.im2);
        im3 = findViewById(R.id.im3);
        im4 = findViewById(R.id.im4);
        im5 = findViewById(R.id.im5);
        im6 = findViewById(R.id.im6);
        im7 = findViewById(R.id.im7);
        im8 = findViewById(R.id.im8);
        im9 = findViewById(R.id.im9);
        txt = findViewById(R.id.txtView);
        btnAgain = findViewById(R.id.btnAgain);
        btnAgain.setVisibility(View.GONE);

        List<Integer> list = Arrays.asList(imgs);
        Collections.shuffle(list);
        list.toArray(imgs);

    }


    public void im1(View view) {
        im1.setImageResource(imgs[0]);
        if (imgs[0] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im2(View view) {
        im2.setImageResource(imgs[1]);
        if (imgs[1] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im3(View view) {
        im3.setImageResource(imgs[2]);
        if (imgs[2] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im4(View view) {
        im4.setImageResource(imgs[3]);
        if (imgs[3] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im5(View view) {
        im5.setImageResource(imgs[4]);
        if (imgs[4] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im6(View view) {
        im6.setImageResource(imgs[5]);
        if (imgs[5] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im7(View view) {
        im7.setImageResource(imgs[6]);
        if (imgs[6] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im8(View view) {
        im8.setImageResource(imgs[7]);
        if (imgs[7] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void im9(View view) {
        im9.setImageResource(imgs[8]);
        if (imgs[8] == R.drawable.starbucks)
            System.exit(0);
        else
            count+=1;
        if(count == 8) {
            btnAgain.setVisibility(View.VISIBLE);
            txt.setText("Finally , You have completed all levels");
            Toast.makeText(this, "You Won", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnAgain(View view) {
        Intent intent = new Intent(this , MainActivity.class);
        startActivity(intent);
    }
}