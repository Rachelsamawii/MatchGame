package com.example.matchgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

    public class splashScreenActivity extends AppCompatActivity {
//    ImageView img;
//    Integer [] imgs  = {R.drawable.ameed , R.drawable.blk , R.drawable.blend , R.drawable.gerard , R.drawable.matrix};
//    int count = 0;
//    private int currentImageIndex = 0;
//    private Handler handler;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_splash_screen);
//        img = findViewById(R.id.imgView);
//        handler = new Handler();
//
//        handler.postDelayed(, 0);
//        List<Integer> list = Arrays.asList(imgs);
//        Collections.shuffle(list);
//        list.toArray(imgs);
//
//
//
//
//
//    }
//}

    //public class SplashScreenActivity extends AppCompatActivity {

    private ImageView splashImageView;
    private int[] splashImages = {R.drawable.ameed , R.drawable.blk , R.drawable.blend , R.drawable.gerard , R.drawable.matrix};
    private int currentImageIndex = 0;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        splashImageView = findViewById(R.id.imgView);
        handler = new Handler();
        handler.postDelayed(imageChangeRunnable, 0);
    }

    private Runnable imageChangeRunnable = new Runnable() {
        @Override
        public void run() {
            if (currentImageIndex < splashImages.length) {
                // Change the splash image
                splashImageView.setImageResource(splashImages[currentImageIndex]);
                currentImageIndex++;
                handler.postDelayed(this, 500);
            }
            else {
                startActivity(new Intent(splashScreenActivity.this, MainActivity.class));
                finish();
            }
        }
    };
}